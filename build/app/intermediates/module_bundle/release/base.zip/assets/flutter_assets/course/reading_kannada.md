# Reading Kannada | ಕನ್ನಡ ಓದಕ್ಕೆ

### Before we start to learn Kannada, it is important that you have at least rudimentary knowledge on how to read the script and pronounce each letter. While all the Kannada examples will be given in the Kananda script along with its transcription and an English translation, it is still a good idea to learn to read the characters to further immerse yourself in this langauge.
### The Kannada script is known as an abugida, which means that consonat-vowel sequences are written as one character; the consonant is the base while the vowel is indicated using diacritics. It is read from left to right.

## Vowels | ಸ್ವರ

## Consonants | ವ್ಯಜನ
